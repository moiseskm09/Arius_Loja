    <table cellspacing="0" cellpadding="0" width="100%" border="0">
      <tr class="tdEscura">
        <td align="center"><img src="<? echo IMAGE_PATH?>ico_alerta.gif" align="absmiddle">&nbsp;<b>Nenhum registro foi encontrado.</b></td>
      </tr>
    </table>
