<?php
$endereco_bd='localhost';
$usuario_bd='root';
$senha_bd='m221213';
$base_principal='siga';
?>
